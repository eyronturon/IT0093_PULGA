import Foundation

struct AnnouncementDTO: Codable {
    let title: String
    let date: String
    let category: String
    let location: String?
    let priority: String?
    let priorityLevel: String?
    let postedBy: String?

    var resolvedPriority: String {
        let value = (priorityLevel ?? priority ?? "Normal")
            .trimmingCharacters(in: .whitespacesAndNewlines)
        return value.isEmpty ? "Normal" : value
    }
}
