import UIKit

class AnnouncementCell: UITableViewCell {

    @IBOutlet weak var categoryIconImageView: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var dateLabel: UILabel!

    func configure(with announcement: CampusAnnouncement) {
        titleLabel.text = announcement.title

        if announcement.priority == "Urgent" {
            dateLabel.text = "\(announcement.category) • \(announcement.date) • URGENT"
            categoryIconImageView.image = UIImage(systemName: "exclamationmark.circle.fill")
            categoryIconImageView.tintColor = .systemRed
            titleLabel.textColor = .systemRed
            dateLabel.textColor = .systemRed
            backgroundColor = UIColor.systemRed.withAlphaComponent(0.1)
        } else {
            dateLabel.text = "\(announcement.category) • \(announcement.date)"
            categoryIconImageView.image = UIImage(systemName: "megaphone.fill")
            categoryIconImageView.tintColor = .systemBlue
            titleLabel.textColor = .label
            dateLabel.textColor = .secondaryLabel
            backgroundColor = .systemBackground
        }
    }
}
