import UIKit

class ViewController: UIViewController {

    // MARK: - Outlets (connect these from Main.storyboard)
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var subtitleLabel: UILabel!
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var getStartedButton: UIButton!

    // MARK: - View Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground

        // If you want to ensure initial text/fonts match your previous setup:
        titleLabel.text = "Campus Companion"
        titleLabel.font = UIFont.boldSystemFont(ofSize: 32)
        titleLabel.textAlignment = .center

        subtitleLabel.text = "Welcome to your campus app"
        subtitleLabel.font = UIFont.systemFont(ofSize: 18)
        subtitleLabel.textAlignment = .center
        subtitleLabel.textColor = .darkGray
        subtitleLabel.numberOfLines = 0

        imageView.image = UIImage(named: "welcome_image")
        imageView.contentMode = .scaleAspectFit

        getStartedButton.setTitle("Get Started", for: .normal)
        getStartedButton.titleLabel?.font = UIFont.boldSystemFont(ofSize: 20)
    }

    // MARK: - Actions (connect Touch Up Inside from the button)
    @IBAction func getStartedTapped(_ sender: UIButton) {
        subtitleLabel.text = "Let's get started!"
    }
}
